import  java.util.Scanner;

// главный клас программы
public class Furkalo1
{
// главная функция класа
    public static void main(String[] args)
    {

//      чисельная переменная для введенного числа
        double number = 0;

//      запрос на ввод числа
        System.out.print("Введите число: ");

//      проверка является ли введенное числом
        try (Scanner typed = new Scanner(System.in))
        {
            if (typed.hasNextDouble())
            {
                number = typed.nextDouble();
            }
            else
            {
                System.out.println("Упсс... произошла ошибка ввода");
            }
        }

//      проверка числа на соответствие условию и вывод в консоль
        if (number > 7)
        {
            System.out.println("Привет");
        }
    }
}