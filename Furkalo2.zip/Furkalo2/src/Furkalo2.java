import java.io.*;

// главный клас программы
public class Furkalo2
{

// главная функция программы
    public static void main(String[] args)
    {
//      переменные и начальное условие
	    String name = "Вячеслав";
	    String newName = "";

//      запрос и ввод с консоли и обработка возможных ошибок ввода
        System.out.print("Введите имя: ");
        InputStreamReader typedInput = new InputStreamReader(System.in);
        BufferedReader buffer = new BufferedReader(typedInput);

//       обработка возможных ошибок ввода
        try
        {
            newName = buffer.readLine();
            buffer.close();
        }
        catch (IOException e)
        {
            System.out.println("Упсс... произошла ошибка ввода");
        }

//       проверка условия и вывод результата в консоль
        if (name.equals(newName))
        {
            System.out.println("Привет, " + newName);
        }
        else
        {
            System.out.println("Нет такого имени");
        }

    }
}
