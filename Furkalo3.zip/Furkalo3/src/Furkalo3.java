import java.io.*;
import java.util.*;
import java.util.stream.Collectors;

// главный клас программы
public class Furkalo3
{
//  главная функция класа
    public static void main(String[] args)
    {
//        переменные
        List<Double> newList1 = new ArrayList<Double>();
        String newInput = "";
//        вывод приглашения и ввод элементов
        System.out.print("Введите элементы числового массива через пробел : ");
        InputStreamReader typedInput = new InputStreamReader(System.in);
        BufferedReader buffer = new BufferedReader(typedInput);
//        обработка возможных ошибок ввода
        try
        {
            newInput = buffer.readLine();
            buffer.close();
        }
        catch (IOException e)
        {
            System.out.println("Упсс... произошла ошибка ввода");
        }
//        проверка на то являются ли введенные данные чисельными
        try
        {
            double[] newList = Arrays.stream(newInput.split(" ")).mapToDouble(Double::parseDouble).toArray();
            newList1 = Arrays.stream(newList).boxed().collect(Collectors.toList());
        }
        catch (NumberFormatException | NullPointerException nfe)
        {
            System.out.println("Вводить нужно только числа через 1 пробел и использовать '.' для разделителя дробей");
        }
//        перебор масива и форматированный вывод в консоль элементов кратных "3"
        System.out.print(" элементы массива кратные 3: ");
        for (int i = 0; i < newList1.size(); i++)
        {
            if (newList1.get(i) % 3 == 0 && newList1.get(i) !=0)
            {
               System.out.printf("%.0f ",newList1.get(i));
            }
        }

    }
}



